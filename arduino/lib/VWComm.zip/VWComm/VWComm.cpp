#include "VWComm.h" //include the declaration for this class
 
 
//<<constructor>> 
VWComm::VWComm(){
}
 
//<<destructor>>
VWComm::~VWComm(){/*nothing to destruct*/}
 
void VWComm::sendByte(byte b){
  char msg[1];
  msg[0] = 66;  // send "B" to indicate Byte
  vw_send((uint8_t *)msg, 1);
  vw_wait_tx(); // Wait until the whole message is gone 
  delay(200);
  msg[0]={b};
  vw_send((uint8_t *)msg, 1);
  vw_wait_tx(); // Wait until the whole message is gone 
}

void VWComm::sendInt(int i){
  char msg[2];
  msg[0] = 73;  // send "I" to indicate Integer
  vw_send((uint8_t *)msg, 1);
  vw_wait_tx(); // Wait until the whole message is gone 
  delay(200);
  msg[0]=lowByte(i);
  msg[1]=highByte(i);
  vw_send((uint8_t *)msg, 2);
  vw_wait_tx(); // Wait until the whole message is gone   
}

void VWComm::sendStr(String s){
  char msg[100];
  unsigned int L;
  msg[0] = 83;  // send "S" to indicate String
  vw_send((uint8_t *)msg, 1);
  vw_wait_tx(); // Wait until the whole message is gone 
  delay(200);
  L=s.length();
  if(L>27){
    s=s.substring(0,26); //truncate it
  }
  L=L+1;
  s.toCharArray(msg,L);
  vw_send((uint8_t *)msg, L);
  vw_wait_tx(); // Wait until the whole message is gone  
}

void VWComm::sendFloat(float f,byte dp){
  int n;
  int w;
  int z;
  float x;
  char msg[27];
  char whole[10];
  char frac[10];
  
  msg[0] = 70;  // send "F" to indicate Float
  vw_send((uint8_t *)msg, 1);
  vw_wait_tx(); // Wait until the whole message is gone 
  delay(200);
  w=int(f); // Get integer part of number
  n=snprintf(whole,10,"%d",w); // store it in whole
  x=(f - float(w))*pow(10,dp)+0.5;
  z=int(x); // get numbers after decimal point
  n=snprintf(frac,10,"%d",z); // store it in frac
  n=sprintf(msg, "%s.%s",whole,frac); // reassemble as string
  vw_send((uint8_t *)msg, strlen(msg)+1); //send string
  vw_wait_tx(); // Wait until the whole message is gone  
}

int VWComm::readInt() {
  uint8_t buf[VW_MAX_MESSAGE_LEN];
  uint8_t buflen = VW_MAX_MESSAGE_LEN;
  int retVal;

  vw_wait_rx();
  if (vw_get_message(buf, &buflen)) // Non-blocking
  {
    if (buflen < 2) { //received byte
      retVal = int(buf[0]);
    }
    else {
      retVal = buf[0] + 256 * buf[1];
    }
    return (retVal);
  }
}

byte VWComm::readByte() {
  uint8_t buf[VW_MAX_MESSAGE_LEN];
  uint8_t buflen = VW_MAX_MESSAGE_LEN;

  vw_wait_rx();
  if (vw_get_message(buf, &buflen)) // Non-blocking
  {
    return (buf[0]);
  }
}

String VWComm::readStr() {
  uint8_t buf[VW_MAX_MESSAGE_LEN];
  uint8_t buflen = VW_MAX_MESSAGE_LEN;
  String s = "";
  byte i = 0;

  vw_wait_rx();
  if (vw_get_message(buf, &buflen)) // Non-blocking
  {
    while (buf[i] != 0) {
      //for(i=0;i<5;i++){
      s = s + char(buf[i]);
      i = i + 1;
    }
    s = s + char(0);
    return (s);
  }
}

float VWComm::readFloat(){
  String s="";
  String temp="";
  float x;
  float y;
  int p;
  
  s=readStr(); // get incoming string containing float
  p=s.indexOf("."); // locate decimal point
  temp = s.substring(0,p); //get integer part
  x=float(temp.toInt()); //convert to float
  temp="";
  temp = s.substring(p+1); // get fractional part
  y=float(temp.toInt()); // read as whole number
  p=temp.length(); //how many dp to shift
  y=y/pow(10,p); //apply shift
  x=x+y; // reconstruct floating value
  return(x);
}

String VWComm::dataType() {
  int i;
  i = readInt();
  return (String(char(i)));
}

