#ifndef VWComm_H
#define VWComm_H

#include <Arduino.h>
#include <VirtualWire.h>

class VWComm {
public:
        VWComm();
        ~VWComm();
        void sendByte(byte b);
        void sendInt(int i);
        void sendStr(String s);
	void sendFloat(float f,byte dp);
	byte readByte();
	int readInt();
	String readStr();
	float readFloat();
	String dataType();
};
 
#endif